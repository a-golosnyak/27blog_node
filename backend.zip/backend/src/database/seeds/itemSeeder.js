// export const
// import  faker  from 'faker'
// let faker = require('faker')

console.log('Here user seeder! -------')
// console.log(faker.name.findName())

let userSeeder = {
    a: '1',
    seedData() {
        console.log('Here seeder 1 ! -------')
    }
}


module.exports = userSeeder;