console.log('Here nodemon build --- 2 -----------------------------');


// let a = 1;
// console.log("--- 1 --------------------")
// console.log(a);
//
//
// setTimeout( () =>
// 	{
// 		a = 0;
// 		console.log("--- 2 --------------------")
// 		console.log(a);
// 	}, 1000);
//
// console.log("--- 3 --------------------")
// console.log(a);

