# API design in Node.js with Express
> Andrey Golosnyak


### Testing
THe other resources don't have any test, go ahead and write some!

export class User {...}	            import {User} from ...
export default class User {...}     import User from ...
